package com.bachhs.springlogstash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringToLogstashApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringToLogstashApplication.class, args);
	}

}
